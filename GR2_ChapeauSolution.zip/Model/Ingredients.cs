﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    class Ingredients
    {
        public int Ingr_ID { get; set; }
        public int Ingr_Name { get; set; }
    }
}
