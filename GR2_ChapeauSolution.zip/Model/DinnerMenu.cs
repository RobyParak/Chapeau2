﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    class DinnerMenu
    {
        public List<Dish> Dishes { get; set; }
    }
}
