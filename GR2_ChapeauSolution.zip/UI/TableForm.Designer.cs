﻿namespace UI
{
    partial class TableForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTable1 = new System.Windows.Forms.Button();
            this.btnTable2 = new System.Windows.Forms.Button();
            this.btnTable3 = new System.Windows.Forms.Button();
            this.btnTable4 = new System.Windows.Forms.Button();
            this.btnTable5 = new System.Windows.Forms.Button();
            this.btnTable6 = new System.Windows.Forms.Button();
            this.btnTable7 = new System.Windows.Forms.Button();
            this.btnTable8 = new System.Windows.Forms.Button();
            this.btnTable9 = new System.Windows.Forms.Button();
            this.btnTable10 = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblLogout = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRefreshTabelData = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnTable1
            // 
            this.btnTable1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable1.Location = new System.Drawing.Point(134, 111);
            this.btnTable1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable1.Name = "btnTable1";
            this.btnTable1.Size = new System.Drawing.Size(45, 46);
            this.btnTable1.TabIndex = 0;
            this.btnTable1.Text = "1";
            this.btnTable1.UseVisualStyleBackColor = true;
            this.btnTable1.Click += new System.EventHandler(this.btnTable1_Click);
            // 
            // btnTable2
            // 
            this.btnTable2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable2.Location = new System.Drawing.Point(232, 111);
            this.btnTable2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable2.Name = "btnTable2";
            this.btnTable2.Size = new System.Drawing.Size(45, 46);
            this.btnTable2.TabIndex = 1;
            this.btnTable2.Text = "2";
            this.btnTable2.UseVisualStyleBackColor = true;
            this.btnTable2.Click += new System.EventHandler(this.btnTable2_Click);
            // 
            // btnTable3
            // 
            this.btnTable3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable3.Location = new System.Drawing.Point(134, 192);
            this.btnTable3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable3.Name = "btnTable3";
            this.btnTable3.Size = new System.Drawing.Size(45, 46);
            this.btnTable3.TabIndex = 2;
            this.btnTable3.Text = "3";
            this.btnTable3.UseVisualStyleBackColor = true;
            this.btnTable3.Click += new System.EventHandler(this.btnTable3_Click);
            // 
            // btnTable4
            // 
            this.btnTable4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable4.Location = new System.Drawing.Point(232, 192);
            this.btnTable4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable4.Name = "btnTable4";
            this.btnTable4.Size = new System.Drawing.Size(45, 46);
            this.btnTable4.TabIndex = 3;
            this.btnTable4.Text = "4";
            this.btnTable4.UseVisualStyleBackColor = true;
            this.btnTable4.Click += new System.EventHandler(this.btnTable4_Click);
            // 
            // btnTable5
            // 
            this.btnTable5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable5.Location = new System.Drawing.Point(134, 284);
            this.btnTable5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable5.Name = "btnTable5";
            this.btnTable5.Size = new System.Drawing.Size(45, 46);
            this.btnTable5.TabIndex = 4;
            this.btnTable5.Text = "5";
            this.btnTable5.UseVisualStyleBackColor = true;
            this.btnTable5.Click += new System.EventHandler(this.btnTable5_Click);
            // 
            // btnTable6
            // 
            this.btnTable6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable6.Location = new System.Drawing.Point(232, 284);
            this.btnTable6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable6.Name = "btnTable6";
            this.btnTable6.Size = new System.Drawing.Size(45, 46);
            this.btnTable6.TabIndex = 5;
            this.btnTable6.Text = "6";
            this.btnTable6.UseVisualStyleBackColor = true;
            this.btnTable6.Click += new System.EventHandler(this.btnTable6_Click);
            // 
            // btnTable7
            // 
            this.btnTable7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable7.Location = new System.Drawing.Point(134, 364);
            this.btnTable7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable7.Name = "btnTable7";
            this.btnTable7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnTable7.Size = new System.Drawing.Size(45, 46);
            this.btnTable7.TabIndex = 6;
            this.btnTable7.Text = "7";
            this.btnTable7.UseVisualStyleBackColor = true;
            this.btnTable7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnTable8
            // 
            this.btnTable8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable8.Location = new System.Drawing.Point(232, 364);
            this.btnTable8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable8.Name = "btnTable8";
            this.btnTable8.Size = new System.Drawing.Size(45, 46);
            this.btnTable8.TabIndex = 7;
            this.btnTable8.Text = "8";
            this.btnTable8.UseVisualStyleBackColor = true;
            this.btnTable8.Click += new System.EventHandler(this.btnTable8_Click);
            // 
            // btnTable9
            // 
            this.btnTable9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable9.Location = new System.Drawing.Point(134, 454);
            this.btnTable9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable9.Name = "btnTable9";
            this.btnTable9.Size = new System.Drawing.Size(45, 46);
            this.btnTable9.TabIndex = 8;
            this.btnTable9.Text = "9";
            this.btnTable9.UseVisualStyleBackColor = true;
            this.btnTable9.Click += new System.EventHandler(this.btnTable9_Click);
            // 
            // btnTable10
            // 
            this.btnTable10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTable10.Location = new System.Drawing.Point(232, 454);
            this.btnTable10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTable10.Name = "btnTable10";
            this.btnTable10.Size = new System.Drawing.Size(45, 46);
            this.btnTable10.TabIndex = 9;
            this.btnTable10.Text = "10";
            this.btnTable10.UseVisualStyleBackColor = true;
            this.btnTable10.Click += new System.EventHandler(this.btnTable10_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(304, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(106, 36);
            this.btnLogout.TabIndex = 11;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblLogout
            // 
            this.lblLogout.AutoSize = true;
            this.lblLogout.Location = new System.Drawing.Point(169, 17);
            this.lblLogout.Name = "lblLogout";
            this.lblLogout.Size = new System.Drawing.Size(0, 20);
            this.lblLogout.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(154, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 41);
            this.label1.TabIndex = 13;
            this.label1.Text = "Tables";
            // 
            // btnRefreshTabelData
            // 
            this.btnRefreshTabelData.Location = new System.Drawing.Point(6, 13);
            this.btnRefreshTabelData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRefreshTabelData.Name = "btnRefreshTabelData";
            this.btnRefreshTabelData.Size = new System.Drawing.Size(74, 59);
            this.btnRefreshTabelData.TabIndex = 14;
            this.btnRefreshTabelData.Text = "Refresh";
            this.btnRefreshTabelData.UseVisualStyleBackColor = true;
            this.btnRefreshTabelData.Click += new System.EventHandler(this.btnRefreshTabelData_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(71, 528);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(19, 24);
            this.button1.TabIndex = 15;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(71, 564);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(19, 24);
            this.button2.TabIndex = 16;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button3.Location = new System.Drawing.Point(258, 528);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(19, 24);
            this.button3.TabIndex = 17;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button4.Location = new System.Drawing.Point(258, 564);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(19, 24);
            this.button4.TabIndex = 18;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 530);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "Booked";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 566);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "Available";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(304, 532);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "Served";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(304, 566);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Seated";
            // 
            // TableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(415, 600);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnRefreshTabelData);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblLogout);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnTable10);
            this.Controls.Add(this.btnTable9);
            this.Controls.Add(this.btnTable8);
            this.Controls.Add(this.btnTable7);
            this.Controls.Add(this.btnTable6);
            this.Controls.Add(this.btnTable5);
            this.Controls.Add(this.btnTable4);
            this.Controls.Add(this.btnTable3);
            this.Controls.Add(this.btnTable2);
            this.Controls.Add(this.btnTable1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "TableForm";
            this.Text = "TableForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTable1;
        private System.Windows.Forms.Button btnTable2;
        private System.Windows.Forms.Button btnTable3;
        private System.Windows.Forms.Button btnTable4;
        private System.Windows.Forms.Button btnTable5;
        private System.Windows.Forms.Button btnTable6;
        private System.Windows.Forms.Button btnTable7;
        private System.Windows.Forms.Button btnTable8;
        private System.Windows.Forms.Button btnTable9;
        private System.Windows.Forms.Button btnTable10;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblLogout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRefreshTabelData;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}