﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Model;

namespace UI
{
    public partial class BarViewForm : Form
    {
        public BarViewForm(Staff staff)
        {
            InitializeComponent();
        }
    }
}
